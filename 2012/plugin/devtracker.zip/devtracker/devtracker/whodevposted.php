<?php

// ############################### start whodev_posted ###############################
// hooks into "misc_start" via the plugin interface in the AdminCP
// Re-used the code from vBulletin's whoposted, except we filter for only admin
if ($_REQUEST['do'] == 'whodevposted')
{
	if (!$threadinfo['threadid'] OR $threadinfo['isdeleted'] OR (!$threadinfo['visible'] AND !can_moderate($threadinfo['forumid'], 'canmoderateposts')))
	{
		eval(standard_error(fetch_error('invalidid', $vbphrase['thread'], $vbulletin->options['contactuslink'])));
	}

	($hook = vBulletinHook::fetch_hook('misc_whoposted_start')) ? eval($hook) : false;

	$forumperms = fetch_permissions($threadinfo['forumid']);
	if (!($forumperms & $vbulletin->bf_ugp_forumpermissions['canview']) OR !($forumperms & $vbulletin->bf_ugp_forumpermissions['canviewthreads']))
	{
		print_no_permission();
	}
	if (!($forumperms & $vbulletin->bf_ugp_forumpermissions['canviewothers']) AND ($threadinfo['postuserid'] != $vbulletin->userinfo['userid'] OR !$vbulletin->userinfo['userid']))
	{
		print_no_permission();
	}

	$posts = $db->query_read_slave("
		SELECT COUNT(postid) AS posts,
		post.username AS postuser,user.userid,user.username
		FROM " . TABLE_PREFIX . "post AS post
		LEFT JOIN " . TABLE_PREFIX . "user AS user USING(userid)
		WHERE threadid = $threadinfo[threadid]
			AND visible = 1
				AND user.usergroupid = 6
		GROUP BY userid
		ORDER BY posts DESC
	");

	$totalposts = 0;
	$posters = '';
	if ($db->num_rows($posts))
	{
		require_once(DIR . '/includes/functions_bigthree.php');
		while ($post = $db->fetch_array($posts))
		{

			$ast = '';

			exec_switch_bg();
			if ($post['username'] == '')
			{
				$post['username'] = $post['postuser'];
			}
			$post['username'] .=  $ast;
			$totalposts += $post['posts'];
			$post['posts'] = vb_number_format($post['posts']);
			$show['memberlink'] = iif ($post['userid'], true, false);
			eval('$posters .= "' . fetch_template('whopostedbit') . '";');
		}
		$totalposts = vb_number_format($totalposts);

		($hook = vBulletinHook::fetch_hook('misc_whoposted_complete')) ? eval($hook) : false;

		eval('print_output("' . fetch_template('WHOPOSTED') . '");');
	}
	else
	{
		eval(standard_error(fetch_error('invalidid', $vbphrase['thread'], $vbulletin->options['contactuslink'])));
	}
}

?>